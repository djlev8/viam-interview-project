from typing import (Any, ClassVar, Dict, Final, List, Mapping, Optional,
                    Sequence, Tuple)

from typing_extensions import Self
from viam.components.sensor import Sensor
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import Geometry, ResourceName
from viam.resource.base import ResourceBase
from viam.resource.easy_resource import EasyResource
from viam.resource.types import Model, ModelFamily
from viam.utils import SensorReading, ValueTypes

from viam.services.vision import Vision
from viam.services.vision import VisionClient

class Pdetect(Sensor, EasyResource):
    # To enable debug-level logging, either run viam-server with the --debug option,
    # or configure your resource/machine to display debug logs.
    MODEL: ClassVar[Model] = Model(ModelFamily("dl-org", "sensor-pd"), "pdetect")

    def __init__(self, name: str):
        super().__init__(name)
        self.vision: Optional[VisionClient] = None

    @classmethod
    def new(
        cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ) -> Self:
        """This method creates a new instance of this Sensor component.
        The default implementation sets the name from the `config` parameter and then calls `reconfigure`.

        Args:
            config (ComponentConfig): The configuration for this resource
            dependencies (Mapping[ResourceName, ResourceBase]): The dependencies (both implicit and explicit)

        Returns:
            Self: The resource
        """
        sensor = cls(config.name)
        sensor.reconfigure(config, dependencies)
        return sensor

    @classmethod
    def validate_config(
        cls, config: ComponentConfig
    ) -> Tuple[Sequence[str], Sequence[str]]:
        """This method allows you to validate the configuration object received from the machine,
        as well as to return any required dependencies or optional dependencies based on that `config`.

        Args:
            config (ComponentConfig): The configuration for this resource

        Returns:
            Tuple[Sequence[str], Sequence[str]]: A tuple where the
                first element is a list of required dependencies (myPeopleDetector) and the
                second element is a list of optional dependencies (none)
        """
        if "camera_name" not in config.attributes.fields:
            raise Exception("Missing required attribute: camera_name")
        return ["myPeopleDetector"], []

    def reconfigure(
        self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ):
        """This method allows you to dynamically update your service when it receives a new `config` object.

        Args:
            config (ComponentConfig): The new configuration
            dependencies (Mapping[ResourceName, ResourceBase]): Any dependencies (both implicit and explicit)
        """
        if not config.attributes or "camera_name" not in config.attributes.fields:
            raise ValueError("Missing required attribute: camera_name")
            
        self.camera_name = str(config.attributes.fields["camera_name"].string_value)
        
        vision_resource = dependencies.get(ResourceName(namespace="rdk", type=Vision.API, name="myPeopleDetector"))
        if not vision_resource:
            raise ValueError("Required dependency 'myPeopleDetector' not found")
            
        self.vision = vision_resource
        return super().reconfigure(config, dependencies)

    async def get_readings(
        self,
        *,
        extra: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs
    ) -> Mapping[str, SensorReading]:
        """
        Get the current reading from the person detection sensor.

        This method queries the vision service to determine whether a person is detected
        in the camera feed. It uses the `do_command` method internally and returns a 
        standardized `SensorReading` object containing either a 1 (person detected) or 0 
        (no person detected).

        Args:
            extra: Optional metadata or additional parameters (unused in this case).
            timeout: Optional timeout value for the operation.
            **kwargs: Additional optional keyword arguments.

        Returns:
            A dictionary with a single key `"person_detected"` mapped to a `SensorReading`
            with an integer value of 1 or 0.
        """
        result = await self.do_command({})
        return {"person_detected": SensorReading(int(result["person_detected"]))}
    
    async def do_command(
        self,
        command: Mapping[str, ValueTypes],
        *,
        timeout: Optional[float] = None,
        **kwargs
    ) -> Mapping[str, ValueTypes]:
        """
        Handle a custom command to detect whether a person is present in the camera view.

        This method calls the configured vision service ("myPeopleDetector") and queries it
        for object detections from the specified camera ("cam"). If at least one detection 
        has the class name "person" with a confidence above 0.5, the method returns:

            {"person_detected": 1}

        Otherwise, it returns:

            {"person_detected": 0}

        This function enables a simplified custom sensor interface for checking 
        person presence based on existing detection logic.

        Args:
            command (Mapping[str, ValueTypes]): Input command parameters (unused).
            timeout (Optional[float]): Optional timeout for the request.
            **kwargs: Additional keyword arguments.

        Returns:
            Mapping[str, ValueTypes]: A dictionary with a single key `"person_detected"` 
            set to 1 (person found) or 0 (not found).
        """
        detections = await self.vision.get_detections_from_camera(self.camera_name)
        for d in detections:
            if d.class_name.lower() == "person" and d.confidence > 0.5:
                return {"person_detected": 1}
        return {"person_detected": 0}

    async def get_geometries(
        self, *, extra: Optional[Dict[str, Any]] = None, timeout: Optional[float] = None
    ) -> List[Geometry]:
        self.logger.error("`get_geometries` is not implemented")
        raise NotImplementedError()

